[app]
title = Systematic Trader Pro
package.name = systematictraderpro
package.domain = org.systematictrader
source.dir = .
source.include_exts = py,png,jpg,kv
version = 1.0.0
requirements = python3,kivy,requests
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
warn_on_root = 1
