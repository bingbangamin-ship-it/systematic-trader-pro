
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
from .capital_engine import Ledger
from .exchange import ExchangeGateway
from .assets import ASSETS
app=FastAPI(title="Systematic Trader Pro Final")
ledger=Ledger()

@app.get("/status")
def status():
    return {"equity":ledger.equity,"cash":ledger.cash,"paper":True,
            "motors":[m.__dict__|{"equity":m.equity} for m in ledger.motors]}

@app.get("/assets")
def assets():
    return {"count":len(ASSETS),"assets":[a.json() for a in ASSETS]}

@app.get("/pnl")
def pnl():
    rows=[a.json() for a in ASSETS]
    return {"total_pnl":sum(x["pnl"] for x in rows),"assets":rows}

@app.post("/motor/{mid}/core-close")
def core(mid:int,l2_end:float,l2l3_end:float):return ledger.core_close(mid,l2_end,l2l3_end)

@app.post("/motor/{mid}/meme-split")
def meme(mid:int,start:float,end:float):return ledger.meme_split(mid,start,end)

@app.post("/motor/create")
def create():return {"created":ledger.create_motor(),"count":len(ledger.motors)}

class Req(BaseModel):
    exchange:str="binance";symbol:str="BTC/USDT"

@app.post("/market/ticker")
def ticker(r:Req):
    try:return ExchangeGateway(r.exchange,True).ticker(r.symbol)
    except Exception as e:raise HTTPException(400,str(e))
